#pragma once
#include "Model.h"
#include "Camera.h"
#include "Shaders.h"
#include "Textures.h"

#include <random>
#include <algorithm>
#include <iostream>
#include <glm/gtc/type_ptr.hpp>


struct StaticObject {
    std::unique_ptr<Model> model;
    GLuint textureID;
    glm::vec3 position;
    glm::vec3 rotation;
    glm::vec3 scale;
    std::string name;
    bool isTarget = false;

    StaticObject(const StaticObject&) = delete;
    StaticObject& operator=(const StaticObject&) = delete;

    StaticObject() = default;
    StaticObject(StaticObject&&) = default;
    StaticObject& operator=(StaticObject&&) = default;
};

struct Airship {
    std::unique_ptr<Model> model;
    GLuint textureID;
    glm::vec3 position;
    glm::vec3 rotation;
    glm::vec3 scale;
    glm::vec3 velocity;
    float speed;

    Airship() :
        position(0.0f, 10.0f, 0.0f),
        rotation(0.0f, 0.0f, 0.0f),
        scale(0.005f, 0.005f, 0.005f),
        velocity(0.0f),
        speed(5.0f) {
    }

    void Update(float deltaTime) {
        position += velocity * deltaTime;
    }

    void MoveForward() {
        glm::vec3 forward = glm::vec3(
            sin(glm::radians(rotation.y)),
            0,
            cos(glm::radians(rotation.y))
        );
        velocity = forward * speed;
    }

    void MoveBackward() {
        glm::vec3 backward = glm::vec3(
            -sin(glm::radians(rotation.y)),
            0,
            -cos(glm::radians(rotation.y))
        );
        velocity = backward * speed;
    }

    void MoveLeft() {
        rotation.y += 1.0f;
    }

    void MoveRight() {
        rotation.y -= 1.0f;
    }

    void MoveUp() {
        position.y += speed * 0.1f;
    }

    void MoveDown() {
        position.y -= speed * 0.1f;
    }

    void Stop() {
        velocity = glm::vec3(0.0f);
    }

    glm::vec3 GetCameraPosition() {
        return glm::vec3(position.x - 10, position.y + 10, position.z);
    }

};

struct Present {
    std::unique_ptr<Model> model;
    GLuint textureID;
    glm::vec3 position;
    glm::vec3 velocity;
    glm::vec3 scale;
    glm::vec3 rotation;
    float lifeTime;
    bool active;
    std::string targetName;

    Present() :
        position(0.0f),
        velocity(0.0f),
        scale(glm::vec3(0.5f, 0.5f, 0.5f)),
        rotation(glm::vec3(-90.0f, 0.0f, 0.0f)),
        lifeTime(5.0f),
        active(false) {
    }
};

class PresentSystem {
private:
    std::vector<Present> presents;
    glm::vec3 gravity = glm::vec3(0.0f, -3.0f, 0.0f);
    float throwSpeed = 10.0f;

public:
    PresentSystem() {}

    void CreatePresent(const glm::vec3& startPosition, const glm::vec3& targetPosition,
        const std::string& targetName) {
                if (presents.size() > 10) {
                    presents.erase(
                        std::remove_if(presents.begin(), presents.end(),
                            [](const Present& g) { return !g.active; }),
                        presents.end()
                    );
                }

                Present present;
                present.position = startPosition;
                present.active = true;
                present.lifeTime = 5.0f;
                present.targetName = targetName;

                glm::vec3 direction = glm::normalize(targetPosition - startPosition);
                float distance = glm::distance(startPosition, targetPosition);

                float timeToTarget = distance / throwSpeed;
                glm::vec3 horizontalVelocity = direction * throwSpeed;

                float verticalVelocity = (targetPosition.y - startPosition.y) / timeToTarget +
                    (0.5f * glm::length(gravity) * timeToTarget);

                present.velocity = glm::vec3(horizontalVelocity.x, verticalVelocity, horizontalVelocity.z);

                if (InitializePresentModel(present)) {
                    presents.push_back(std::move(present));
                }
    }

    void Update(float deltaTime) {
        for (auto& present : presents) {
            if (!present.active) continue;

            present.velocity += gravity * deltaTime;
            present.position += present.velocity * deltaTime;

            present.rotation.y += 100.0f * deltaTime;

            present.lifeTime -= deltaTime;

            if (present.position.y < -2.0f || present.lifeTime <= 0.0f) {
                present.active = false;
            }
        }
    }

    void Draw(GLuint shaderProgram) {
        for (const auto& present : presents) {
            if (!present.active || !present.model) continue;

            glm::mat4 model = glm::mat4(1.0f);
            model = glm::translate(model, present.position);
            model = glm::rotate(model, glm::radians(present.rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
            model = glm::rotate(model, glm::radians(present.rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
            model = glm::rotate(model, glm::radians(present.rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
            model = glm::scale(model, present.scale);

            glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE,
                glm::value_ptr(model));

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, present.textureID);
            glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);

            present.model->Draw();
        }
    }

    size_t GetActivePresentsCount() const {
        return std::count_if(presents.begin(), presents.end(),
        [](const Present& g) { return g.active; });
    }

    void Clear() {
        presents.clear();
    }

    glm::vec3 FindNearestTarget(const glm::vec3& startPosition,
        const std::vector<struct StaticObject>& objects,
        std::string& targetName)
    {

        float minDistance = std::numeric_limits<float>::max();
        glm::vec3 nearestTarget(0.0f);
        targetName = "";

        for (const auto& obj : objects) {
            if (obj.isTarget) {
                float distance = glm::distance(startPosition, obj.position);
                if (distance < minDistance) {
                    minDistance = distance;
                    nearestTarget = obj.position;
                    targetName = obj.name;
                }
            }
        }
        return nearestTarget;
    }
private:
    

    bool InitializePresentModel(Present& present) {
        present.model = std::make_unique<Model>();
        if (!present.model->LoadFromOBJ("models/model_present.obj")) {
            std::cerr << "Failed to load model_present.obj for present" << std::endl;
            return false;
        }
        present.textureID = LoadTextureFromFile("textures/texture_present.png");
        return present.textureID != 0;
    }
};

PresentSystem presentSystem;
Airship airship;
std::vector<StaticObject> staticObjects;

bool IsPositionValid(const glm::vec3& newPos, const std::vector<glm::vec3>& existingPositions, float minDistance) {
    for (const auto& pos : existingPositions) {
        float distance = glm::distance(newPos, pos);
        if (distance < minDistance) {
            return false;
        }
    }
    return true;
}

void RandomizeObjectPositions() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dist(-40.0f, 40.0f);  

    std::vector<glm::vec3> existingPositions;
    const float minDistance = 8.0f;  
    const int maxAttempts = 10;    

    for (auto& obj : staticObjects) {
        if (obj.name == "Christmas Tree" || obj.name == "Ground") {
            existingPositions.push_back(obj.position);
            continue;
        }

        bool positionFound = false;
        glm::vec3 newPosition;
        int attempts = 0;

        while (!positionFound && attempts < maxAttempts) {
            newPosition = glm::vec3(dist(gen), obj.position.y, dist(gen));

            if (IsPositionValid(newPosition, existingPositions, minDistance)) {
                positionFound = true;
                obj.position = newPosition;
                existingPositions.push_back(newPosition);

                std::cout << "Object '" << obj.name << "' placed at: ("
                    << newPosition.x << ", " << newPosition.y << ", " << newPosition.z << ")" << std::endl;
            }
            attempts++;
        }

        if (!positionFound) {
            std::cerr << "Warning: Could not find valid position for object '"
                << obj.name << "', keeping original position." << std::endl;
            existingPositions.push_back(obj.position);
        }
    }
}

bool LoadStaticScene() {
    staticObjects.clear();

    // ������ 1
    StaticObject obj1;
    obj1.name = "Ground";
    obj1.model = std::make_unique<Model>();
    if (!obj1.model->LoadFromOBJ("models/cube.obj")) {
        std::cerr << "Failed to load cube.obj" << std::endl;
        return false;
    }
    obj1.position = glm::vec3(0.0f, -11.0f, 0.0f);
    obj1.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj1.scale = glm::vec3(50.0f, 10.0f, 50.0f);

    obj1.textureID = LoadTextureFromFile("textures/texture_ground.png");
    staticObjects.push_back(std::move(obj1));

    StaticObject obj2;
    obj2.name = "Christmas Tree";
    obj2.model = std::make_unique<Model>();
    if (!obj2.model->LoadFromOBJ("models/model_christmastree.obj")) {
        std::cerr << "Failed to load model_christmastree.obj" << std::endl;
        return false;
    }
    obj2.textureID = LoadTextureFromFile("textures/texture_christmastree.png");
    obj2.position = glm::vec3(0.0f, -0.4f, 0.0f);
    obj2.rotation = glm::vec3(-90.0f, 0.0f, 0.0f);
    obj2.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj2));

    StaticObject obj3;
    obj3.name = "House 1";
    obj3.model = std::make_unique<Model>();
    if (!obj3.model->LoadFromOBJ("models/model_house1.obj")) {
        std::cerr << "Failed to load model_house1.obj" << std::endl;
        return false;
    }
    obj3.textureID = LoadTextureFromFile("textures/texture_house1.png");
    obj3.position = glm::vec3(4.0f, 0.2f, 2.0f);
    obj3.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj3.scale = glm::vec3(3.0f, 3.0f, 3.0f);
    obj3.isTarget = true;
    staticObjects.push_back(std::move(obj3));

    StaticObject obj4;
    obj4.name = "House 2";
    obj4.model = std::make_unique<Model>();
    if (!obj4.model->LoadFromOBJ("models/model_house2.obj")) {
        std::cerr << "Failed to load model_house2.obj" << std::endl;
        return false;
    }
    obj4.textureID = LoadTextureFromFile("textures/texture_house2.png");
    obj4.position = glm::vec3(4.0f, 1.5f, 2.0f);
    obj4.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj4.scale = glm::vec3(3.0f, 3.0f, 3.0f);
    obj4.isTarget = true;

    staticObjects.push_back(std::move(obj4));

    StaticObject obj5;
    obj5.name = "House 3";
    obj5.model = std::make_unique<Model>();
    if (!obj5.model->LoadFromOBJ("models/model_house3.obj")) {
        std::cerr << "Failed to load model_house3.obj" << std::endl;
        return false;
    }
    obj5.textureID = LoadTextureFromFile("textures/texture_house3.png");
    obj5.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj5.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj5.scale = glm::vec3(3.0f, 3.0f, 3.0f);
    obj5.isTarget = true;

    staticObjects.push_back(std::move(obj5));

    StaticObject obj6;
    obj6.name = "House 4";
    obj6.model = std::make_unique<Model>();
    if (!obj6.model->LoadFromOBJ("models/model_house4.obj")) {
        std::cerr << "Failed to load model_house4.obj" << std::endl;
        return false;
    }
    obj6.textureID = LoadTextureFromFile("textures/texture_house4.png");
    obj6.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj6.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj6.scale = glm::vec3(3.0f, 3.0f, 3.0f);
    obj6.isTarget = true;
    staticObjects.push_back(std::move(obj6));

    StaticObject obj7;
    obj7.name = "House 5";
    obj7.model = std::make_unique<Model>();
    if (!obj7.model->LoadFromOBJ("models/model_house5.obj")) {
        std::cerr << "Failed to load model_house5.obj" << std::endl;
        return false;
    }
    obj7.textureID = LoadTextureFromFile("textures/texture_house5.png");
    obj7.position = glm::vec3(4.0f, 1.5f, 2.0f);
    obj7.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj7.scale = glm::vec3(3.0f, 3.0f, 3.0f);
    obj7.isTarget = true;
    staticObjects.push_back(std::move(obj7));

    StaticObject obj8;
    obj8.name = "House 5-2";
    obj8.model = std::make_unique<Model>();
    if (!obj8.model->LoadFromOBJ("models/model_house5.obj")) {
        std::cerr << "Failed to load model_house5.obj" << std::endl;
        return false;
    }
    obj8.textureID = LoadTextureFromFile("textures/texture_house5.png");
    obj8.position = glm::vec3(4.0f, 1.5f, 2.0f);
    obj8.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj8.scale = glm::vec3(3.0f, 3.0f, 3.0f);
    obj8.isTarget = true;
    staticObjects.push_back(std::move(obj8));

    StaticObject obj9;
    obj9.name = "Car 1";
    obj9.model = std::make_unique<Model>();
    if (!obj9.model->LoadFromOBJ("models/model_car1.obj")) {
        std::cerr << "Failed to load model_car1.obj" << std::endl;
        return false;
    }
    obj9.textureID = LoadTextureFromFile("textures/texture_car1.png");
    obj9.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj9.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj9.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj9));

    StaticObject obj10;
    obj10.name = "Car 1-2";
    obj10.model = std::make_unique<Model>();
    if (!obj10.model->LoadFromOBJ("models/model_car1.obj")) {
        std::cerr << "Failed to load model_car1.obj" << std::endl;
        return false;
    }
    obj10.textureID = LoadTextureFromFile("textures/texture_car1.png");
    obj10.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj10.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj10.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj10));

    StaticObject obj11;
    obj11.name = "Car 1-3";
    obj11.model = std::make_unique<Model>();
    if (!obj11.model->LoadFromOBJ("models/model_car1.obj")) {
        std::cerr << "Failed to load model_car1.obj" << std::endl;
        return false;
    }
    obj11.textureID = LoadTextureFromFile("textures/texture_car1.png");
    obj11.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj11.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj11.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj11));

    StaticObject obj12;
    obj12.name = "Car 2-1";
    obj12.model = std::make_unique<Model>();
    if (!obj12.model->LoadFromOBJ("models/model_car2.obj")) {
        std::cerr << "Failed to load model_car2.obj" << std::endl;
        return false;
    }
    obj12.textureID = LoadTextureFromFile("textures/texture_car2.png");
    obj12.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj12.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj12.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj12));

    StaticObject obj13;
    obj13.name = "Car 2-2";
    obj13.model = std::make_unique<Model>();
    if (!obj13.model->LoadFromOBJ("models/model_car2.obj")) {
        std::cerr << "Failed to load model_car2.obj" << std::endl;
        return false;
    }
    obj13.textureID = LoadTextureFromFile("textures/texture_car2.png");
    obj13.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj13.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj13.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj13));

    StaticObject obj14;
    obj14.name = "Car 2-3";
    obj14.model = std::make_unique<Model>();
    if (!obj14.model->LoadFromOBJ("models/model_car2.obj")) {
        std::cerr << "Failed to load model_car2.obj" << std::endl;
        return false;
    }
    obj14.textureID = LoadTextureFromFile("textures/texture_car2.png");
    obj14.position = glm::vec3(4.0f, 0.5f, 2.0f);
    obj14.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj14.scale = glm::vec3(1.0f, 1.0f, 1.0f);
    staticObjects.push_back(std::move(obj14));

    StaticObject obj15;
    obj15.name = "Cloud";
    obj15.model = std::make_unique<Model>();
    if (!obj15.model->LoadFromOBJ("models/model_cloud.obj")) {
        std::cerr << "Failed to load model_cloud.obj" << std::endl;
        return false;
    }
    obj15.textureID = LoadTextureFromFile("textures/texture_cloud.png");
    obj15.position = glm::vec3(4.0f, 50.0f, 2.0f);
    obj15.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj15.scale = glm::vec3(2.7f, 2.7f, 2.7f);
    staticObjects.push_back(std::move(obj15));

    StaticObject obj16;
    obj16.name = "Cloud 2";
    obj16.model = std::make_unique<Model>();
    if (!obj16.model->LoadFromOBJ("models/model_cloud.obj")) {
        std::cerr << "Failed to load model_cloud.obj" << std::endl;
        return false;
    }
    obj16.textureID = LoadTextureFromFile("textures/texture_cloud.png");
    obj16.position = glm::vec3(4.0f, 50.0f, 2.0f);
    obj16.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj16.scale = glm::vec3(2.7f, 2.7f, 2.7f);
    staticObjects.push_back(std::move(obj16));

    StaticObject obj17;
    obj17.name = "Cloud 3";
    obj17.model = std::make_unique<Model>();
    if (!obj17.model->LoadFromOBJ("models/model_cloud.obj")) {
        std::cerr << "Failed to load model_cloud.obj" << std::endl;
        return false;
    }
    obj17.textureID = LoadTextureFromFile("textures/texture_cloud.png");
    obj17.position = glm::vec3(4.0f, 50.0f, 2.0f);
    obj17.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj17.scale = glm::vec3(2.7f, 2.7f, 2.7f);
    staticObjects.push_back(std::move(obj17));

    StaticObject obj18;
    obj18.name = "Cloud 4";
    obj18.model = std::make_unique<Model>();
    if (!obj18.model->LoadFromOBJ("models/model_cloud.obj")) {
        std::cerr << "Failed to load model_cloud.obj" << std::endl;
        return false;
    }
    obj18.textureID = LoadTextureFromFile("textures/texture_cloud.png");
    obj18.position = glm::vec3(4.0f, 50.0f, 2.0f);
    obj18.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj18.scale = glm::vec3(2.7f, 2.7f, 2.7f);
    staticObjects.push_back(std::move(obj18));

    StaticObject obj19;
    obj19.name = "Cloud 5";
    obj19.model = std::make_unique<Model>();
    if (!obj19.model->LoadFromOBJ("models/model_cloud.obj")) {
        std::cerr << "Failed to load model_cloud.obj" << std::endl;
        return false;
    }
    obj19.textureID = LoadTextureFromFile("textures/texture_cloud.png");
    obj19.position = glm::vec3(4.0f, 50.0f, 2.0f);
    obj19.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj19.scale = glm::vec3(2.7f, 2.7f, 2.7f);
    staticObjects.push_back(std::move(obj19));

    StaticObject obj20;
    obj20.name = "Balloon";
    obj20.model = std::make_unique<Model>();
    if (!obj20.model->LoadFromOBJ("models/model_balloon.obj")) {
        std::cerr << "Failed to load model_balloon.obj" << std::endl;
        return false;
    }
    obj20.textureID = LoadTextureFromFile("textures/texture_balloon.png");
    obj20.position = glm::vec3(4.0f, 25.0f, 2.0f);
    obj20.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj20.scale = glm::vec3(8.0f, 8.0f, 8.0f);
    staticObjects.push_back(std::move(obj20));

    StaticObject obj21;
    obj21.name = "Balloon 2";
    obj21.model = std::make_unique<Model>();
    if (!obj21.model->LoadFromOBJ("models/model_balloon.obj")) {
        std::cerr << "Failed to load model_balloon.obj" << std::endl;
        return false;
    }
    obj21.textureID = LoadTextureFromFile("textures/texture_balloon.png");
    obj21.position = glm::vec3(4.0f, 25.0f, 2.0f);
    obj21.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj21.scale = glm::vec3(8.0f, 8.0f, 8.0f);
    staticObjects.push_back(std::move(obj21));

    StaticObject obj22;
    obj22.name = "Balloon 3";
    obj22.model = std::make_unique<Model>();
    if (!obj22.model->LoadFromOBJ("models/model_balloon.obj")) {
        std::cerr << "Failed to load model_balloon.obj" << std::endl;
        return false;
    }
    obj22.textureID = LoadTextureFromFile("textures/texture_balloon.png");
    obj22.position = glm::vec3(4.0f, 25.0f, 2.0f);
    obj22.rotation = glm::vec3(0.0f, 0.0f, 0.0f);
    obj22.scale = glm::vec3(8.0f, 8.0f, 8.0f);
    staticObjects.push_back(std::move(obj22));


    // ���������
    airship.model = std::make_unique<Model>();
    if (!airship.model->LoadFromOBJ("models/model_airship.obj")) {
        std::cerr << "Failed to load model_airship.obj" << std::endl;
        return false;
    }
    airship.textureID = LoadTextureFromFile("textures/texture1_airship.png");

    RandomizeObjectPositions();

    return true;
}