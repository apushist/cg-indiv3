#pragma once
#include <GL/glew.h>

bool InitShader(GLuint& shaderProgram);