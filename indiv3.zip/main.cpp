﻿#include <GL/glew.h>
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#include <filesystem>
#include <string>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Objects.h" 

struct DirLight {
    glm::vec3 direction;    
    glm::vec3 ambient;      
    glm::vec3 diffuse;       
    glm::vec3 specular;     

    DirLight() :
        direction(glm::vec3(-0.2f, -1.0f, -0.3f)), 
        ambient(glm::vec3(0.3f, 0.3f, 0.3f)),
        diffuse(glm::vec3(0.8f, 0.8f, 0.8f)),
        specular(glm::vec3(0.5f, 0.5f, 0.5f)) {
    }
};


enum CameraMode {
    CAMERA_FREE,      
    CAMERA_FOLLOW     
};

Camera camera;
CameraMode cameraMode = CAMERA_FOLLOW;

GLuint shaderProgram;
float deltaTime = 0.0f;
sf::Clock gameClock;

DirLight dirLight;



void SetDirLightUniforms(GLuint shaderProgram, const DirLight& light) {
    glm::vec3 normalizedDir = glm::normalize(light.direction);
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.direction"),
        normalizedDir.x, normalizedDir.y, normalizedDir.z);
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.ambient"),
        light.ambient.x, light.ambient.y, light.ambient.z);
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.diffuse"),
        light.diffuse.x, light.diffuse.y, light.diffuse.z);
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.specular"),
        light.specular.x, light.specular.y, light.specular.z);
}

int main() {
    sf::Window window(sf::VideoMode({ 1000, 800 }), "3D Scene");
    window.setVerticalSyncEnabled(true);
    window.setActive(true);

    GLenum err = glewInit();
    if (err != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW: " << glewGetErrorString(err) << std::endl;
        return -1;
    }
    glEnable(GL_DEPTH_TEST);
    glClearColor(0.1f, 0.1f, 0.15f, 1.0f);

    if (!InitShader(shaderProgram)) {
        std::cerr << "Failed to initialize shader!" << std::endl;
        return -1;
    }

    if (!LoadStaticScene()) {
        std::cerr << "Failed to load static scene!" << std::endl;
        return -1;
    }

    std::cout << "Static scene loaded successfully!" << std::endl;
    std::cout << "Objects in scene: " << staticObjects.size() << std::endl;
    for (const auto& obj : staticObjects) {
        std::cout << "  - " << obj.name << std::endl;
    }

    std::cout << "\nCAMERA MOVEMENT:" << std::endl;
    std::cout << "  Space - Move forward" << std::endl;
    std::cout << "  LShift - Move backward" << std::endl;
    std::cout << "  Mouse Wheel - Zoom in/out" << std::endl;
    std::cout << "  R - Reset camera" << std::endl;
    std::cout << "  C - Toggle camera mode (Free/Follow airship)" << std::endl;

    std::cout << "\nLIGHT CONTROLS:" << std::endl;
    std::cout << "  N/M - Increase/Decrease light intensity" << std::endl;

    std::cout << "\nAIRSHIP CONTROLS:" << std::endl;
    std::cout << "  W - Move forward" << std::endl;
    std::cout << "  S - Move backward" << std::endl;
    std::cout << "  A - Turn left" << std::endl;
    std::cout << "  D - Turn right" << std::endl;
    std::cout << "  Q - Move up" << std::endl;
    std::cout << "  E - Move down" << std::endl;

    std::cout << "\nGIFT CONTROLS:" << std::endl;
    std::cout << "  F - Throw present to nearest target" << std::endl;

    std::cout << "\n  Escape - Exit program" << std::endl;

    camera.SetPosition(glm::vec3(25.0f, 20.0f, 0.0f));
    camera.LookAt(glm::vec3(0.0f, 0.0f, 0.0f));

    float mouseSensitivity = 0.3f;
    float zoomSpeed = 2.0f;
    bool rotatingCamera = false;
    float lastMouseX = 0.0f;
    float lastMouseY = 0.0f;
    float followDist = 25.0f;

    while (window.isOpen()) {
        deltaTime = gameClock.restart().asSeconds();
        float moveSpeed = 6.0f * deltaTime;
        airship.Update(deltaTime);
        presentSystem.Update(deltaTime);
        if (cameraMode == CAMERA_FOLLOW) {
            glm::vec3 airshipForward = glm::vec3(
                sin(glm::radians(airship.rotation.y)),
                0,
                cos(glm::radians(airship.rotation.y))
            );
            camera.FollowTarget(airship.position, airshipForward, followDist, 8.0f, deltaTime);
        }

        while (auto event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) {
                window.close();
            }

            if (event->is<sf::Event::Resized>()) {
                const auto& sizeEvent = event->getIf<sf::Event::Resized>();
                if (sizeEvent) {
                    int width = sizeEvent->size.x;
                    int height = sizeEvent->size.y;

                    glViewport(0, 0, width, height);
                    camera.SetAspectRatio(static_cast<float>(width) / height);
                }
            }

            if (event->is<sf::Event::MouseButtonPressed>()) {
                const auto& btn = event->getIf<sf::Event::MouseButtonPressed>();
                if (btn && btn->button == sf::Mouse::Button::Left && cameraMode == CAMERA_FREE) {
                    rotatingCamera = true;
                    lastMouseX = static_cast<float>(btn->position.x);
                    lastMouseY = static_cast<float>(btn->position.y);
                }
            }

            if (event->is<sf::Event::MouseButtonReleased>()) {
                const auto& buttonEvent = event->getIf<sf::Event::MouseButtonReleased>();
                if (buttonEvent ) {
                    if (buttonEvent->button == sf::Mouse::Button::Left) {
                        rotatingCamera = false;
                    }
                }
            }

            if (event->is<sf::Event::MouseMoved>()) {
                const auto& mouse = event->getIf<sf::Event::MouseMoved>();
                if (mouse && rotatingCamera && cameraMode == CAMERA_FREE) {
                    float xoffset = mouse->position.x - lastMouseX;
                    float yoffset = lastMouseY - mouse->position.y;
                    lastMouseX = static_cast<float>(mouse->position.x);
                    lastMouseY = static_cast<float>(mouse->position.y);

                    camera.Rotate(xoffset * mouseSensitivity, yoffset * mouseSensitivity);
                }
            }

            if (event->is<sf::Event::MouseWheelScrolled>()) {
                const auto& wheel = event->getIf<sf::Event::MouseWheelScrolled>();

                if (wheel && wheel->wheel == sf::Mouse::Wheel::Vertical && cameraMode == CAMERA_FREE) {
                    if (wheel->delta > 0) {
                        camera.MoveForward(zoomSpeed);
                    }
                    else {
                        camera.MoveBackward(zoomSpeed);
                    }
                }
                else if (wheel && wheel->wheel == sf::Mouse::Wheel::Vertical && cameraMode == CAMERA_FOLLOW){
                    if (wheel->delta > 0) {
                        followDist -= zoomSpeed;
                    }
                    else {
                        followDist += zoomSpeed;
                    }
                }
            }

            if (event->is<sf::Event::KeyPressed>()) {
                const auto& keyEvent = event->getIf<sf::Event::KeyPressed>();
                if (keyEvent) {
                    if (keyEvent->scancode == sf::Keyboard::Scancode::Escape) {
                        window.close();
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::R && cameraMode == CAMERA_FREE) {
                        camera = Camera();
                        camera.SetPosition(glm::vec3(0.0f, 0.0f, 15.0f));
                        camera.LookAt(glm::vec3(0.0f, 0.0f, 0.0f));
                        std::cout << "Camera reset" << std::endl;
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::C) {
                        if (cameraMode == CAMERA_FREE) {
                            cameraMode = CAMERA_FOLLOW;
                            std::cout << "Camera mode: FOLLOW AIRSHIP" << std::endl;
                        }
                        else {
                            cameraMode = CAMERA_FREE;
                            std::cout << "Camera mode: FREE" << std::endl;
                        }
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::N) {
                        dirLight.diffuse *= 1.2f;
                        dirLight.ambient *= 1.2f;
                        dirLight.specular *= 1.2f;
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::M) {
                        dirLight.diffuse *= 0.8f;
                        dirLight.ambient *= 0.8f;
                        dirLight.specular *= 0.8f;
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::W) {
                        airship.MoveForward();
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::S) {
                        airship.MoveBackward();
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::A) {
                        airship.MoveLeft();
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::D) {
                        airship.MoveRight();
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::Q) {
                        airship.MoveUp();
                    }
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::E) {
                        airship.MoveDown();
                    }  
                    else if (keyEvent->scancode == sf::Keyboard::Scancode::F) {
                        std::string targetName;
                        glm::vec3 nearestTarget = presentSystem.FindNearestTarget(
                            airship.position, staticObjects, targetName);

                        if (targetName != "") {
                            presentSystem.CreatePresent(airship.position, nearestTarget, targetName);
                        }
                        else {
                            std::cout << "No target found!" << std::endl;
                        }
                    }
                }
                
            }
            if (event->is<sf::Event::KeyReleased>()) {
                const auto& keyEvent = event->getIf<sf::Event::KeyReleased>();
                if (keyEvent) {
                    if (keyEvent->scancode == sf::Keyboard::Scancode::W ||
                        keyEvent->scancode == sf::Keyboard::Scancode::S) {
                        airship.Stop();
                    }
                }
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::Space) && cameraMode == CAMERA_FREE) {
                camera.MoveForward(moveSpeed);
            }
            else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::LShift) && cameraMode == CAMERA_FREE) {
                camera.MoveBackward(moveSpeed);
            }

        }


        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(shaderProgram);

        glm::mat4 view = camera.GetViewMatrix();
        glm::mat4 projection = camera.GetProjectionMatrix(camera.GetAspectRatio());

        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

        glm::vec3 viewPos = camera.GetPosition();
        glUniform3f(glGetUniformLocation(shaderProgram, "viewPos"), viewPos.x, viewPos.y, viewPos.z);

        SetDirLightUniforms(shaderProgram, dirLight);

        // Отрисовка всех статических объектов
        for (const auto& obj : staticObjects) {
            glm::mat4 model = glm::mat4(1.0f);
            model = glm::translate(model, obj.position);
            model = glm::rotate(model, glm::radians(obj.rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
            model = glm::rotate(model, glm::radians(obj.rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
            model = glm::rotate(model, glm::radians(obj.rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
            model = glm::scale(model, obj.scale);

            glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, obj.textureID);
            glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);

            obj.model->Draw();
        }

        glm::mat4 model = glm::mat4(1.0f);
        model = glm::translate(model, airship.position);
        model = glm::rotate(model, glm::radians(airship.rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
        model = glm::rotate(model, glm::radians(airship.rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
        model = glm::rotate(model, glm::radians(airship.rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
        model = glm::scale(model, airship.scale);

        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, airship.textureID);
        glUniform1i(glGetUniformLocation(shaderProgram, "texture1"), 0);

        airship.model->Draw();
        presentSystem.Draw(shaderProgram);

        window.display();
    }

    return 0;
}