#ifndef MODEL_H
#define MODEL_H

#include <vector>
#include <map>
#include <tuple>
#include <string>
#include <glm/glm.hpp>

#ifdef _WIN32
#include <GL/glew.h>
#else
#endif

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>


struct Vertex {
    float x, y, z;
};

struct TexCoord {
    float u, v;
};

struct Normal {
    float x, y, z;
};

class Model {
private:
    unsigned int VAO, VBO_Vertices, VBO_TexCoords, VBO_Normals, EBO;
    bool isInitialized;

    std::vector<Vertex> vertices;
    std::vector<TexCoord> texCoords;
    std::vector<Normal> normals;
    std::vector<unsigned int> indices;

    void Cleanup();

public:
    Model();
    Model(Model&& other) noexcept;
    Model& operator=(Model&& other) noexcept;
    ~Model();

    void Clear();
    void SetupBuffers();
    bool LoadFromOBJ(const std::string& filename);

    void ProcessAssimpNode(aiNode* node, const aiScene* scene);

    void ProcessAssimpMesh(aiMesh* mesh, const aiScene* scene);

    void SetData(const std::vector<Vertex>& verts,
        const std::vector<TexCoord>& texs,
        const std::vector<Normal>& norms,
        const std::vector<unsigned int>& inds);

    void Draw() const;

    bool IsInitialized() const { return isInitialized; }

    glm::vec3 GetMin() const;
    glm::vec3 GetMax() const;
    glm::vec3 GetSize() const;

};

#endif // MODEL_H