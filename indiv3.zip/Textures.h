#pragma once
#include <GL/glew.h>
#include <string>

GLuint LoadTextureFromFile(const std::string& path);